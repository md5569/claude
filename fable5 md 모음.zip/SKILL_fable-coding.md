---
name: fable-coding
description: 폐쇄망(방산망) 환경 기준의 완결성 있는 코드 작성 규칙. 사용자가 코드 작성, 수정, 리팩토링, 스크립트 생성, 자동화(RPA, Selenium, pywin32), Python/PowerShell 작업을 요청하면 — "코드"라는 단어를 쓰지 않았더라도(예: "이거 자동으로 되게 해줘", "엑셀 비교 프로그램") — 반드시 이 스킬을 적용하라. 디버깅·오류 분석 요청에도 적용된다.
---

# Fable 코딩 스킬 (Sonnet/Opus용)

<!-- 배치 위치: 프로젝트/.claude/skills/fable-coding/SKILL.md
     설계: 본문 50줄 이내, 환경별 상세는 references/로 분리 (progressive disclosure) -->

## 필수 원칙 (모든 코드)

1. **완결성**: 실행 가능한 완성 코드. placeholder·"나머지 동일" 생략 금지. 수정 시 변경 부분 명확히 표시, 요청 시 전체 재출력.
2. **방어적 코딩 기본값**:
   - 파일 I/O: `encoding='utf-8'` 명시, 실패 시 `cp949` 폴백
   - 외부 호출(API·파일·DB): try-except + 원인을 알 수 있는 에러 메시지 (침묵 실패 금지)
   - 경로·포트·모델명: 하드코딩 금지, 파일 상단 상수 블록으로 분리
3. **버전 pin**: `pip install pandas==2.2.3` 형태. "최신 버전 설치하세요" 금지.
4. **설명 밀도**: 코드 앞뒤 장황한 설명 금지. 설명은 한국어 주석으로. 코드 후에는 실행 방법 + 주의점만.
5. **트레이드오프**: 구현 방법이 복수면 선택 이유와 대안 단점 1~2줄. 사용자 방식에 위험이 있으면 요청대로 만들되 경고 먼저.

## 디버깅 요청 시 (코드 재작성 전 필수 절차)

1. root cause 후보를 확률 순으로 제시
2. 각 후보에 5분 내 검증 가능한 명령어·코드 부착
3. 검증 결과에 따라 원인 제거 — try-except로 증상을 덮는 해결 금지

## 코드 출력 전 Self-Check

- [ ] 이 코드가 인터넷 없는 환경에서 그대로 실행되는가 (pip 온라인 설치, 외부 URL 호출 없음)
- [ ] 경로가 `C:\Users\HHI\secu\` 규칙을 따르는가
- [ ] numpy==1.26.4 / torch==2.5.1+cu121 고정을 깨뜨리지 않는가
- [ ] 에러 발생 시 사용자가 원인을 알 수 있는 메시지가 출력되는가

## 환경별 상세 (필요 시에만 읽기)

| 상황 | 참조 파일 |
|---|---|
| 패키지 오프라인 설치·whl 순서 | `references/offline-install.md` |
| vLLM/Ollama 연동 코드 | `references/llm-server.md` |
| RPA (Selenium·pywin32·pyautogui) | `references/rpa.md` |

<!-- references/ 파일 내용 예시 (기존 md 4종의 상세 내용을 여기로 이동):

references/offline-install.md
- whl 경로: C:\Users\A507663\Desktop\AI_PACKAGE\whl (방산망) / C:\Users\HHI\secu\whl (HHI 계정)
- 설치 순서: streamlit→torch(먼저)→sentence-transformers→faiss(택1)→langchain→문서파서→numpy==1.26.4 --force-reinstall(마지막)
- 명령 형식: pip install --no-index --find-links=whl경로 패키지==버전

references/llm-server.md
- vLLM: http://서버IP:18000/v1 (OpenAI 호환), 모델명 qwen3.5-122B-A10B 대소문자 정확히
- 연결 검증 순서: 서버 localhost curl → PC curl → vllmtest.py
- Ollama: gemma3:12b, RTX A4000 기준

references/rpa.md
- pywin32 Outlook: win32com.client.Dispatch("Outlook.Application")
- Selenium: 오프라인 환경이므로 webdriver-manager 사용 금지, 로컬 chromedriver 경로 지정
-->
